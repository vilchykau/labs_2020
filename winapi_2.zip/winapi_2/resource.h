﻿//{{NO_DEPENDENCIES}}
// Включаемый файл, созданный в Microsoft Visual C++.
// Используется winapi_2.rc
//
#define IDC_MYICON                      2
#define IDD_CHANGE                      9
#define IDD_WINAPI2_DIALOG              102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_WINAPI2                     107
#define IDI_SMALL                       108
#define IDC_WINAPI2                     109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     130
#define D                               1001
#define IDC_EDIT_LEFT                   1001
#define IDC_EDIT2                       1002
#define IDC_EDIT_TOP                    1002
#define IDC_EDIT3                       1003
#define IDC_EDIT_RIGHT                  1003
#define IDC_EDIT4                       1004
#define IDC_EDIT_BOTTOM                 1004
#define IDC_STATIC_LEFT                 1005
#define IDC_TOP_STATIC                  1006
#define IDC_RIGHT_STATIC                1007
#define IDC_BOTTOM_STATIC               1008
#define IDC_BUTTON2                     1012
#define IDC_CHECK1                      1014
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
