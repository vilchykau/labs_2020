#pragma once

#include "framework.h"

RECT GetWndSize(HWND hWnd);
RECT GetWindowRectInParent(HWND hWnd);