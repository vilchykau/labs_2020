#pragma once

#include <string>

#include "framework.h"
#include "resource.h"

#include "RectInfo.h"
#include "CommonUtil.h"

void ChangeDialogShow(HINSTANCE hInst, HWND hWnd, RectInfo& info);

