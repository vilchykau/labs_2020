#pragma once

#include "framework.h"
#include "resource.h"

void AboutDialogShow(HINSTANCE hInst, HWND hWnd);